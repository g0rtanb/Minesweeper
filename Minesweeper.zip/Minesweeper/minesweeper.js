startGame(8, 8, 10);

function startGame (WIDTH, HEIGHT, BOMB_COUNT){

    const field = document.querySelector('.field');
    const cellsCount = WIDTH * HEIGHT;
    field.innerHTML = '<button></button>'.repeat(cellsCount);
    const cells = [...field.children];

    let closedCount = cellsCount;

    const bombs = [...Array(cellsCount).keys()]
        .sort(() => Math.random() - 0.5)
        .slice(0, BOMB_COUNT);
    field.addEventListener('contextmenu',  (event)=>{
        if (event.target.tagName !=='BUTTON') {
            return
        }

        const index = cells.indexOf(event.target);
        const column = index % WIDTH;
        const row = Math.floor(index/WIDTH);
        rightClick(row, column);


    })

    field.addEventListener('click' , (event) =>{
        if (event.target.tagName !=='BUTTON') {
            return
        }

        const index = cells.indexOf(event.target);
        const column = index % WIDTH;
        const row = Math.floor(index/WIDTH);
        open(row, column);
    });

    function isValid(row, column) {
        return row>=0
            && row < HEIGHT
            && column>=0
            && column < WIDTH;
    }

    function getCount(row, column){
        let count = 0;
        for (let i = -1; i <= 1; i++){
            for (let j = -1; j <=1 ; j++){
                if (isBomb(row+j, column+i)){
                    count++;
                }
            }
        }
        return count;
    }

    function rightClick(row, column){
        if (!isValid(row, column)) return;
        const index = row*WIDTH + column;
        const cell = cells[index];
        if (cell.enabled === true) return;
        cell.enabled = true;
        cell.innerHTML = '?';
    }

    function open(row, column){
        if (!isValid(row, column)) return;
        const index = row*WIDTH + column;
        const cell = cells[index];
        if (cell.disabled === true) return;
        cell.disabled = true;
        if (isBomb(row, column)) {
            cell.innerHTML = 'X';
            alert("You lose!");
            return;
        }
        closedCount--;
        if (closedCount <= BOMB_COUNT){
            alert ("You won!");
        }


        const count = getCount(row, column);
        if (count !== 0){
            cell.innerHTML = count;
            return;
        }
        for (let i = -1; i <= 1; i++) {
            for (let j = -1; j <= 1; j++) {
                open(row + j, column + i);
            }
        }
    }

    function isBomb(row, column){
        if (!isValid(row, column)) return false;
        const index = row * WIDTH + column;
        return bombs.includes(index);


    }
}